module com.group04.cinemaapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql; // Java SQL paketi için gerekli modül

    opens com.group04.cinemaapp.controllers to javafx.fxml;
    exports com.group04.cinemaapp;
    exports com.group04.cinemaapp.controllers;
    exports com.group04.cinemaapp.models;
}
