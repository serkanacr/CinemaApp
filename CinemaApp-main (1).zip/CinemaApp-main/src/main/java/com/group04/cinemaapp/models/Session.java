package com.group04.cinemaapp.models;

public class Session {
    private int id;
    private String movieName;
    private String date;
    private String time;
    private String hall;

    public Session(int id, String movieName, String date, String time, String hall) {
        this.id = id;
        this.movieName = movieName;
        this.date = date;
        this.time = time;
        this.hall = hall;
    }

    public int getId() {
        return id;
    }

    public String getMovieName() {
        return movieName;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getHall() {
        return hall;
    }
}
