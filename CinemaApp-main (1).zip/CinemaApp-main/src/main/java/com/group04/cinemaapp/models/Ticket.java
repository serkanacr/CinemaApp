package com.group04.cinemaapp.models;

public class Ticket {
    private int id;
    private double ticketPrice;
    private double discountRate;

    // Constructor
    public Ticket(int id, double ticketPrice, double discountRate) {
        this.id = id;
        this.ticketPrice = ticketPrice;
        this.discountRate = discountRate;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "id=" + id +
                ", ticketPrice=" + ticketPrice +
                ", discountRate=" + discountRate +
                '}';
    }
}

