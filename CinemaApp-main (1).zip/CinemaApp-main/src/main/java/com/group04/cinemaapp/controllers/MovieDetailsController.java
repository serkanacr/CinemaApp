package com.group04.cinemaapp.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class MovieDetailsController {

    @FXML
    private Label movieTitleLabel;

    @FXML
    private Label movieGenreLabel;

    @FXML
    private ImageView posterImageView;

    @FXML
    private Label noImageLabel;

    /**
     * Film detaylarını ayarlar.
     *
     * @param title      Filmin başlığı
     * @param genre      Filmin türü
     * @param posterPath Filmin poster yolu
     */
    public void setMovieDetails(String title, String genre, String posterPath) {
        // Film başlığı ve türünü ayarla
        movieTitleLabel.setText(title);
        movieGenreLabel.setText(genre);

        try {
            
            Image posterImage = new Image("file:" + posterPath, true);

            if (posterImage.isError()) {
                throw new IllegalArgumentException("Image not found or invalid.");
            }

            
            posterImageView.setImage(posterImage);
            posterImageView.setVisible(true);
            noImageLabel.setVisible(false);
        } catch (Exception e) {
            
            posterImageView.setImage(null);
            posterImageView.setVisible(false);
            noImageLabel.setVisible(true);
            System.out.println("Image load error: " + e.getMessage());
        }
    }

    /**
     * Detay penceresini kapatır.
     */
    @FXML
    private void handleClose() {
        Stage stage = (Stage) movieTitleLabel.getScene().getWindow();
        stage.close();
    }
}
