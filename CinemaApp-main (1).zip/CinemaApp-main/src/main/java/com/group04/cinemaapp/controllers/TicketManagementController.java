package com.group04.cinemaapp.controllers;
import com.group04.cinemaapp.models.Ticket;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class TicketManagementController {

    @FXML
    private TableView<Ticket> productTable;

    @FXML
    private TableColumn<Ticket, Integer> idColumn;

    @FXML
    private TableColumn<Ticket, Double> ticketPriceColumn;

    @FXML
    private TableColumn<Ticket, Double> discountRateColumn;

    @FXML
    private TextField IDField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField discountField;

    @FXML
    private Button handleUpdateTicket;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/group04";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    private ObservableList<Ticket> ticketList = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        setupTable();
        loadTicketData();
    }

    private void setupTable() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        ticketPriceColumn.setCellValueFactory(new PropertyValueFactory<>("ticketPrice"));
        discountRateColumn.setCellValueFactory(new PropertyValueFactory<>("discountRate"));
    }

    private void loadTicketData() {
        ticketList.clear();
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM settings";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                double ticketPrice = resultSet.getDouble("ticket_price");
                double discountRate = resultSet.getDouble("discount_rate");
                ticketList.add(new Ticket(id, ticketPrice, discountRate));
            }

            productTable.setItems(ticketList);
        } catch (SQLException e) {
            showAlert("Error", "Failed to load data from the database: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleUpdateTicket() {
        String idText = IDField.getText();
        String priceText = priceField.getText();
        String discountText = discountField.getText();

        if (idText.isEmpty() || priceText.isEmpty() || discountText.isEmpty()) {
            showAlert("Validation Error", "Please fill in all fields.", Alert.AlertType.WARNING);
            return;
        }

        try {
            int id = Integer.parseInt(idText);
            double ticketPrice = Double.parseDouble(priceText);
            double discountRate = Double.parseDouble(discountText);

            if (discountRate < 0 || discountRate > 1) {
                showAlert("Validation Error", "Discount rate must be between 0 and 1.", Alert.AlertType.WARNING);
                return;
            }

            updateTicketInDatabase(id, ticketPrice, discountRate);
            loadTicketData();

            showAlert("Success", "Ticket updated successfully.", Alert.AlertType.INFORMATION);
        } catch (NumberFormatException e) {
            showAlert("Validation Error", "Invalid number format. Please enter valid values.", Alert.AlertType.WARNING);
        }
    }

    private void updateTicketInDatabase(int id, double ticketPrice, double discountRate) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "UPDATE settings SET ticket_price = ?, discount_rate = ? WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setDouble(1, ticketPrice);
            statement.setDouble(2, discountRate);
            statement.setInt(3, id);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected == 0) {
                showAlert("Error", "No ticket found with the given ID.", Alert.AlertType.ERROR);
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to update ticket in the database: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleBack() {
        Stage stage = (Stage) IDField.getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String content, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
