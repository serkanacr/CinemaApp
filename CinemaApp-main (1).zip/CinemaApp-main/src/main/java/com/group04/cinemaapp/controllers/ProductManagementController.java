package com.group04.cinemaapp.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import com.group04.cinemaapp.models.Product;

public class ProductManagementController {

    // FXML components
    @FXML private TableView<Product> productTable;
    @FXML private TableColumn<Product, Integer> idColumn;
    @FXML private TableColumn<Product, String> nameColumn;
    @FXML private TableColumn<Product, Double> priceColumn;
    @FXML private TableColumn<Product, Integer> stockColumn;
    @FXML private TextField stockField;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/group04";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    // ObservableList for the products
    private ObservableList<Product> productList = FXCollections.observableArrayList();

    // Initialize method to load products from the database into the TableView
    public void initialize() {
        // Set up the columns to display data
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        priceColumn.setCellValueFactory(cellData -> cellData.getValue().priceProperty().asObject());
        stockColumn.setCellValueFactory(cellData -> cellData.getValue().stockQuantityProperty().asObject());

        // Load products from the database
        loadProducts();
    }

    // Load products from the database
    private void loadProducts() {
        productList.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement()) {
            String sql = "SELECT * FROM products";  // Query to get all products
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                int stockQuantity = rs.getInt("stock_quantity");
                productList.add(new Product(id, name, price, stockQuantity));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        productTable.setItems(productList);  // Set the data to the TableView
    }


    @FXML
    private void handleIncreaseStock(ActionEvent event) {
        Product selectedProduct = productTable.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            // Get the value entered in the stockField (amount to increase)
            String stockText = stockField.getText();
            try {
                int increaseAmount = Integer.parseInt(stockText);
                int newStockQuantity = selectedProduct.getStockQuantity() + increaseAmount;

                // Update the product's stock in the database
                updateProductStock(selectedProduct.getId(), newStockQuantity);

                // Update the stock quantity in the table
                selectedProduct.setStockQuantity(newStockQuantity);

                // Clear the text field after update
                stockField.clear();
            } catch (NumberFormatException e) {
                // Show error if the input is not a valid number
                showError("Invalid input", "Please enter a valid number.");
            }
        } else {
            showError("No product selected", "Please select a product to increase the stock.");
        }
    }

    // Update the stock quantity of a product in the database
    private void updateProductStock(int productId, int newStockQuantity) {
        String sql = "UPDATE products SET stock_quantity = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, newStockQuantity);
            pstmt.setInt(2, productId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            showError("Database error", "Error updating product stock.");
        }
    }
    @FXML private TextField nameField;
    @FXML private TextField priceField;
    @FXML
    private void handleAddProduct(ActionEvent event) {
        try {

            String name = nameField.getText().trim();
            String priceText = priceField.getText().trim();
            String stockQuantityText = stockField.getText().trim();

            if (name.isEmpty() || priceText.isEmpty() || stockQuantityText.isEmpty()) {
                showAlert("Missing Information", "You need to fill all the fields.", Alert.AlertType.WARNING);
                return;  // Bu noktada fonksiyonu sonlandırıyoruz.
            }

            double price = Double.parseDouble(priceText);
            int stockQuantity = Integer.parseInt(stockQuantityText);

            Product newProduct = new Product(0, name, price, stockQuantity);

            productList.add(newProduct);

            saveProductToDatabase(newProduct);

            nameField.clear();
            priceField.clear();
            stockField.clear();

            showAlert("Product Added", "The product has been added successfully.", Alert.AlertType.INFORMATION);

        } catch (NumberFormatException e) {
            showAlert("Invalid Input", "Please enter valid numerical values for price and stock quantity.", Alert.AlertType.ERROR);
        } catch (Exception e) {
            showAlert("Error", "An error occurred while adding the product. Please try again.", Alert.AlertType.ERROR);
        }
    }


    private void saveProductToDatabase(Product product) {
        String sql = "INSERT INTO products (name, price, stock_quantity) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Set parameters for the PreparedStatement
            pstmt.setString(1, product.getName());
            pstmt.setDouble(2, product.getPrice());
            pstmt.setInt(3, product.getStockQuantity());

            // Execute the insert query
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Product added successfully!");
            } else {
                System.out.println("Failed to add product.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while saving the product.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleUpdateProduct(ActionEvent event) {
            Product selectedProduct = productTable.getSelectionModel().getSelectedItem();

            if (selectedProduct != null) {
                String priceText = priceField.getText().trim(); // fiyat alanını alıp boşlukları temizle
                String stockText = stockField.getText().trim(); // stok alanını alıp boşlukları temizle

                if (priceText.isEmpty() || stockText.isEmpty()) {
                    showAlert("Invalid Input", "Please fill all the fields to update the product.", Alert.AlertType.WARNING);
                    return;
                }

                try {
                    double price = Double.parseDouble(priceText);
                    int stockQuantity = Integer.parseInt(stockText);

                    selectedProduct.setName(nameField.getText());
                    selectedProduct.setPrice(price);
                    selectedProduct.setStockQuantity(stockQuantity);

                    updateProductInDatabase(selectedProduct);

                    productTable.refresh();

                    showAlert("Product Updated", "The product has been updated successfully.", Alert.AlertType.INFORMATION);

                } catch (NumberFormatException e) {
                    showAlert("Invalid Format", "Please enter valid numbers for price and stock quantity.", Alert.AlertType.ERROR);
                }
            } else {
                showAlert("No Selection", "Please select a product to update.", Alert.AlertType.WARNING);
            }
            nameField.clear();
            priceField.clear();
            stockField.clear();
    }

    private void updateProductInDatabase(Product product) {
        String sql = "UPDATE products SET name = ?, price = ?, stock_quantity = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, product.getName());
            pstmt.setDouble(2, product.getPrice());
            pstmt.setInt(3, product.getStockQuantity());
            pstmt.setInt(4, product.getId());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Error updating product in the database.", Alert.AlertType.ERROR);
        }
    }


    @FXML
    private void handleDeleteProduct(ActionEvent event) {
        Product selectedProduct = productTable.getSelectionModel().getSelectedItem();

        if (selectedProduct != null) {

            deleteProductFromDatabase(selectedProduct);
            productTable.getItems().remove(selectedProduct);

            showAlert("Product Deleted", "The product has been deleted successfully.", Alert.AlertType.INFORMATION);
        } else {
            showAlert("No Selection", "Please select a product to delete.", Alert.AlertType.WARNING);
        }
    }

    private void deleteProductFromDatabase(Product product) {
        String sql = "DELETE FROM products WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, product.getId());
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "There was an error while deleting the product from the database.", Alert.AlertType.ERROR);
        }
    }


    @FXML
    private void handleBack(ActionEvent event) {
        Stage currentStage = (Stage) productTable.getScene().getWindow();

        currentStage.close();

    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Show error message in an alert dialog
    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

