package com.group04.cinemaapp.controllers;

import com.group04.cinemaapp.Database;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.control.TextField;

import java.io.IOException;

public class ManagerMainMenuController {

    @FXML
    private Button logoutButton;

    @FXML
    private Button manageProductsButton;

    @FXML
    private Button viewReportsButton;

    @FXML
    private Button managePersonnelButton;

    @FXML
    private TextField showUsername;

    @FXML
    public void initialize() {
        // LoginController'dan gelen kullanıcı adını al
        String username = LoginController.loggedInUsername;

        // Null kontrolü yap ve kullanıcı adını göster
        if (username != null && !username.isEmpty()) {
            showUsername.setText(username); // Kullanıcı adını TextField'e yazdır
        } else {
            System.out.println("Username is null or empty."); // Debug için kontrol
            showUsername.setText("Guest"); // Kullanıcı adı yoksa "Guest" yaz
        }
    }

    @FXML
    public void handleLogout(ActionEvent event) {
        try {
            Stage currentStage = (Stage) logoutButton.getScene().getWindow();

            currentStage.close();

            navigateToScreen("/Login.fxml", "Login");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not navigate to the Login page.");
        }
    }

    @FXML
    public void handleManageProducts(ActionEvent event) {
        navigateToScreen("/ProductManagement.fxml", "Product Management");
    }

    @FXML
    public void handleViewReports(ActionEvent event) {
        navigateToScreen("/RevenueReport.fxml", "Revenue Reports");
    }

    @FXML
    public void handleManagePersonnel(ActionEvent event) {
        navigateToScreen("/ManagePersonnel.fxml", "Manage Personnel");
    }

    @FXML
    public void handleTicketPrices(ActionEvent event) {
        navigateToScreen("/ManageTickets.fxml", "Ticket Prices");
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText((String)null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void navigateToScreen(String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(this.getClass().getResource(fxmlPath));
            Parent root = (Parent)loader.load();
            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException var6) {
            this.showAlert("Navigation Error", "Unable to load the screen: " + title, Alert.AlertType.ERROR);
        }

    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
