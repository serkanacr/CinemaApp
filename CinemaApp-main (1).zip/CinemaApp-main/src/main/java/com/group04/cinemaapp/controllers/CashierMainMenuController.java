package com.group04.cinemaapp.controllers;

import com.group04.cinemaapp.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CashierMainMenuController {

    public Button releaseAHallSeatsButton;
    public Button releaseBHallSeatsButton;

    @FXML
    private void handleLogout(ActionEvent event) {
        // Logout logic here
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();
        showAlert("Logout", "You have been logged out successfully.", AlertType.INFORMATION);
        navigateToScreen("/Login.fxml", "Login Screen");
    }

    @FXML
    private void handleSearchMovies(ActionEvent event) {
        // Navigate to the movie search interface
        navigateToScreen("/MovieSearch.fxml", "Search Movies");
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    }

    @FXML
    private void handleManageSeats(ActionEvent event) {
        // Navigate to the seat management interface
        navigateToScreen("/SeatSelection.fxml", "Manage Seats");
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    }

    @FXML
    private void handleProcessPayments(ActionEvent event) {
        // Navigate to the payment processing interface
        navigateToScreen("/ShoppingCart.fxml", "Process Payments");
    }

    private void showAlert(String title, String message, AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void navigateToScreen(String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            showAlert("Navigation Error", "Unable to load the screen: " + title, AlertType.ERROR);
        }
    }
    @FXML
    private void handleReleaseAHallSeats(ActionEvent event) {
        releaseAllSeats("Hall_A");
    }

    @FXML
    private void handleReleaseBHallSeats(ActionEvent event) {
        releaseAllSeats("Hall_B");
    }
    private void releaseAllSeats(String hallName) {
        String updateSeatsQuery = "UPDATE seats s " +
                "INNER JOIN sessions se ON s.session_id = se.id " +
                "SET s.is_reserved = FALSE " +
                "WHERE se.hall_name = ?";

        try (Connection connection = Database.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(updateSeatsQuery)) {

            preparedStatement.setString(1, hallName); // Salonu belirtin (örneğin, "A Hall")
            int rowsUpdated = preparedStatement.executeUpdate();

            if (rowsUpdated > 0) {
                showAlert("Success", hallName + " seats have been released successfully.", Alert.AlertType.INFORMATION);
            } else {
                showAlert("No Seats Found", "No reserved seats found in " + hallName + ".", Alert.AlertType.WARNING);
            }

        } catch (Exception e) {
            showAlert("Database Error", "Unable to release seats for " + hallName + ": " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }


}
