package com.group04.cinemaapp.models;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.BooleanProperty;

public class Seat {

    private final StringProperty seatNumber;
    private final BooleanProperty reserved;

    public Seat(String seatNumber, boolean reserved) {
        this.seatNumber = new SimpleStringProperty(seatNumber);
        this.reserved = new SimpleBooleanProperty(reserved);
    }

    // Getter for Seat Number
    public String getSeatNumber() {
        return seatNumber.get();
    }

    public StringProperty seatNumberProperty() {
        return seatNumber;
    }

    // Getter for Reserved
    public boolean isReserved() {
        return reserved.get();
    }

    public BooleanProperty reservedProperty() {
        return reserved;
    }
}
