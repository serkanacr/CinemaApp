package com.group04.cinemaapp.controllers;

import com.group04.cinemaapp.Database;
import com.group04.cinemaapp.models.Seat;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CancellationController {

    @FXML
    private TableView<Seat> seatsTable;
    @FXML
    private TableColumn<Seat, String> seatNumberColumn;
    @FXML
    private TableColumn<Seat, Boolean> reservedColumn;

    private ObservableList<Seat> seatList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Tabloyu kurmak için koltuk numarasını ve rezervasyon durumunu ayarla
        seatNumberColumn.setCellValueFactory(data -> data.getValue().seatNumberProperty());
        reservedColumn.setCellValueFactory(data -> data.getValue().reservedProperty());

        // Veritabanından koltukları yükle
        seatsTable.setItems(seatList);
        loadSeats();
    }

    /**
     * Koltukları veritabanından alır ve tabloyu günceller.
     */
    private void loadSeats() {
        seatList.clear();
        String query = "SELECT id, seat_number, is_reserved FROM seats";
        try (Connection connection = Database.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String seatNumber = resultSet.getString("seat_number");
                boolean isReserved = resultSet.getBoolean("is_reserved");

                seatList.add(new Seat(seatNumber, isReserved));
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Unable to retrieve seats: " + e.getMessage());
        }
    }

    private void showAlert(String databaseError, String s) {
    }

    /**
     * Koltuk iptalini gerçekleştirir.
     */
    @FXML
    private void cancelSeat(ActionEvent event) {
        Seat selectedSeat = seatsTable.getSelectionModel().getSelectedItem();
        if (selectedSeat != null && selectedSeat.isReserved()) {
            String seatNumber = selectedSeat.getSeatNumber();
            // Koltuğu iptal et
            String query = "UPDATE seats SET is_reserved = false WHERE seat_number = ?";
            try (Connection connection = Database.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, seatNumber);
                int rowsUpdated = preparedStatement.executeUpdate();

                if (rowsUpdated > 0) {
                    showAlert("Success", "Seat " + seatNumber + " has been successfully cancelled.");
                    loadSeats(); // Tabloyu yenile
                } else {
                    showAlert("Error", "Unable to cancel seat " + seatNumber);
                }
            } catch (SQLException e) {
                showAlert("Database Error", "Unable to cancel seat: " + e.getMessage());
            }
        } else {
            showAlert("No Seat Selected", "Please select a reserved seat to cancel.");
        }
    }

    /**
     * Geri dön butonuna tıklanınca ana menüye geçer.
     */
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            // AdminMainMenu.fxml dosyasını yükle
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AdminMainMenu.fxml"));
            Parent root = loader.load();

            // Mevcut sahneyi al ve yeni sahneyle değiştir
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Admin Main Menu");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to navigate back to the Admin Main Menu.");
        }
    }
}



