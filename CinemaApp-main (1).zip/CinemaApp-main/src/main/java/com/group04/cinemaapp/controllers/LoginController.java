package com.group04.cinemaapp.controllers;

import com.group04.cinemaapp.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginController {

    public static String loggedInUsername;
    
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    public void handleLogin(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Username and Password cannot be empty.");
            return;
        }

        try (Connection connection = Database.getConnection()) {
            String query = "SELECT role FROM users WHERE username = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String role = resultSet.getString("role");
                loggedInUsername = username; // Kullanıcı doğrulandıktan sonra ayarla
                loadRoleBasedScene(role);
            } else {
                errorLabel.setText("Invalid username or password.");
            }
        } catch (SQLException e) {
            errorLabel.setText("Database connection error.");
            e.printStackTrace();
        }
    }
    
    private void loadRoleBasedScene(String role) {
        try {
            Stage stage = (Stage) usernameField.getScene().getWindow();
            Parent root;

            switch (role) {
                case "admin":
                    root = FXMLLoader.load(getClass().getResource("/AdminMainMenu.fxml"));
                    break;
                case "cashier":
                    root = FXMLLoader.load(getClass().getResource("/CashierMainMenu.fxml"));
                    break;
                case "manager":
                    root = FXMLLoader.load(getClass().getResource("/ManagerMainMenu.fxml"));
                    break;
                default:
                    errorLabel.setText("Unknown role.");
                    return;
            }

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Cinema Center - " + role.substring(0, 1).toUpperCase() + role.substring(1) + " View");
            stage.show();

        } catch (IOException e) {
            errorLabel.setText("Error loading the scene.");
            e.printStackTrace();
        }
    }

    @FXML
    public void handleCancel(ActionEvent event) {
        Stage stage = (Stage) usernameField.getScene().getWindow();
        stage.close();
    }
}
