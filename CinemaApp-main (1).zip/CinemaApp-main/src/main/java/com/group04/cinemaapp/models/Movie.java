package com.group04.cinemaapp.models;

import javafx.beans.property.*;

public class Movie {

    private final IntegerProperty id;
    private final StringProperty title;
    private final StringProperty genre;
    private final StringProperty summary;
    private final StringProperty posterPath; // Poster Path ekleniyor



    // Constructor
    public Movie(int id, String title, String genre, String summary, String posterPath) {
        this.id = new SimpleIntegerProperty(id);
        this.title = new SimpleStringProperty(title);
        this.genre = new SimpleStringProperty(genre);
        this.summary = new SimpleStringProperty(summary);
        this.posterPath = new SimpleStringProperty(posterPath); // Poster Path de ekleniyor


    }

    public Movie(String title, String genre, String summary, String posterPath) {
        this(0, title, genre, summary, posterPath); // ID için varsayılan değer
    }

    // Getter and Setter for ID
    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public IntegerProperty idProperty() {
        return id;
    }

    // Getter and Setter for Title
    public String getTitle() {
        return title.get();
    }

    public void setTitle(String title) {
        this.title.set(title);
    }

    public StringProperty titleProperty() {
        return title;
    }

    // Getter and Setter for Genre
    public String getGenre() {
        return genre.get();
    }

    public void setGenre(String genre) {
        this.genre.set(genre);
    }

    public StringProperty genreProperty() {
        return genre;
    }

    // Getter and Setter for Summary
    public String getSummary() {
        return summary.get();
    }

    public void setSummary(String summary) {
        this.summary.set(summary);
    }

    public StringProperty summaryProperty() {
        return summary;
    }

    // Getter and Setter for Poster Path
    public String getPosterPath() {
        return posterPath.get();
    }

    public void setPosterPath(String posterPath) {
        this.posterPath.set(posterPath);
    }

    public StringProperty posterPathProperty() {
        return posterPath;
    }


    @Override
    public String toString() {
        return "Movie{" +
                "id=" + getId() +
                ", title='" + getTitle() + '\'' +
                ", genre='" + getGenre() + '\'' +
                ", summary='" + getSummary() + '\'' +
                ", posterPath='" + getPosterPath() + '\'' + // Poster Path de toString'e eklendi
                '}';
    }
}
