package com.group04.cinemaapp.controllers;

import com.group04.cinemaapp.Database;
import com.group04.cinemaapp.models.Movie;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MovieSearchController {

    @FXML
    private TextField searchField;

    @FXML
    private TableView<Movie> moviesTable;

    @FXML
    private TableColumn<Movie, String> titleColumn;

    @FXML
    private TableColumn<Movie, String> genreColumn;

    @FXML
    private TableColumn<Movie, String> summaryColumn;

    private ObservableList<Movie> movieList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        
        titleColumn.setCellValueFactory(data -> data.getValue().titleProperty());
        genreColumn.setCellValueFactory(data -> data.getValue().genreProperty());
        summaryColumn.setCellValueFactory(data -> data.getValue().summaryProperty());

        
        moviesTable.setItems(movieList);
        loadMovies("");
    }

    /**
     * Veritabanından filmleri arar ve tabloyu günceller.
     */
    private void loadMovies(String searchQuery) {
        movieList.clear();
        String query = "SELECT id, title, genre, summary FROM movies WHERE title LIKE ? OR genre LIKE ?";
        try (Connection connection = Database.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, "%" + searchQuery + "%");
            preparedStatement.setString(2, "%" + searchQuery + "%");

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String title = resultSet.getString("title");
                String genre = resultSet.getString("genre");
                String summary = resultSet.getString("summary");

                // Movie nesnesine ekleyin
                movieList.add(new Movie(id, title, genre, summary, ""));
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Unable to retrieve movies: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Arama butonuna tıklandığında çağrılır.
     */
    @FXML
    private void handleSearch(ActionEvent event) {
        String searchText = searchField.getText().trim();
        loadMovies(searchText);
    }

    /**
     * Film seçimini onaylar ve SeatSelection ekranına geçer.
     */
    @FXML
    private void confirmSelection(ActionEvent event) {
        Movie selectedMovie = moviesTable.getSelectionModel().getSelectedItem();
        if (selectedMovie != null) {
            navigateToSeatSelection(selectedMovie);
        } else {
            showAlert("No Movie Selected", "Please select a movie to proceed.", Alert.AlertType.WARNING);
        }
    }

    /**
     * Tablo seçimlerini temizler.
     */
    @FXML
    private void clearSelection(ActionEvent event) {
        moviesTable.getSelectionModel().clearSelection();
    }

    /**
     * Ana menüye geri döner.
     */
    @FXML
    private void goBack(ActionEvent event) {
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();
        navigateToScreen("/CashierMenu.fxml", "Cashier Menu");
    }

    /**
     * SeatSelection ekranına geçiş yapar.
     */
    private void navigateToSeatSelection(Movie selectedMovie) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/SeatSelection.fxml"));
            Parent root = loader.load();

            SeatSelectionController controller = loader.getController();
            controller.setMovieDetails(
                    selectedMovie.getId(),
                    selectedMovie.getTitle(),
                    selectedMovie.getGenre()
            );

            Stage stage = new Stage();
            stage.setTitle("Seat Selection");
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) moviesTable.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            showAlert("Navigation Error", "Unable to navigate to Seat Selection: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Genel ekran geçişi için yardımcı metot.
     */
    private void navigateToScreen(String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) searchField.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            showAlert("Navigation Error", "Unable to navigate to " + title + ": " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Uyarı mesajı gösterir.
     */
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
