package com.group04.cinemaapp.controllers;

import com.group04.cinemaapp.Database;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProductSelectionController {

    @FXML
    private ListView<String> productsListView;

    private int orderId;
    private int sessionId;
    private String seatNumber;

    public void setOrderDetails(int sessionId, String seatNumber) {

        this.sessionId = sessionId;
        this.seatNumber = seatNumber;
    }

    @FXML
    public void initialize() {
        loadProductsFromDatabase();
    }

    /**
     * Veritabanından ürün verilerini yükler.
     */
    private void loadProductsFromDatabase() {
        String query = "SELECT name, price FROM products";
        try (Connection connection = Database.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                String name = resultSet.getString("name");
                double price = resultSet.getDouble("price");
                String displayText = name + " - $" + price;
                productsListView.getItems().add(displayText);
            }
        } catch (Exception e) {
            System.err.println("Error loading products: " + e.getMessage());
        }
    }

    @FXML
    private void handleConfirmSelection() {
        ObservableList<String> selectedProducts = productsListView.getSelectionModel().getSelectedItems();

        if (selectedProducts.isEmpty()) {
            showAlert("No Selection", "Please select at least one product.", Alert.AlertType.WARNING);
            return;
        }

        // ShoppingCartController üzerinden sepeti güncelle
        if (shoppingCartController != null) {
            shoppingCartController.updateShoppingCartView(selectedProducts);
        }

        // Seçilen ürünleri veritabanına kaydet
        boolean isSaved = saveSelectedProductsToDatabase(selectedProducts);

        if (isSaved) {
            showAlert("Success", "Selected products have been added to the cart.", Alert.AlertType.INFORMATION);
        } else {
            showAlert("Error", "Failed to save selected products.", Alert.AlertType.ERROR);
        }

        // Pencereyi kapat
        handleClose();
    }


    // ShoppingCartController referansı
    private ShoppingCartController shoppingCartController;

    // ShoppingCartController referansını ayarlama
    public void setShoppingCartController(ShoppingCartController controller) {
        this.shoppingCartController = controller;
    }


    /**
     * Seçilen ürünleri veritabanına kaydeder.
     */
    private boolean saveSelectedProductsToDatabase(ObservableList<String> selectedProducts) {
        String query = "INSERT INTO orderdetails (session_id, seat_number, product_name, product_price) VALUES (?, ?, ?, ?)";

        try (Connection connection = Database.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            for (String product : selectedProducts) {
                // Ürün adını ve fiyatını ayır
                String[] parts = product.split(" - ");
                String productName = parts[0];
                double productPrice = Double.parseDouble(parts[1].replace("$", ""));

                // session_id kontrol et
                if (sessionId != 0) {
                    preparedStatement.setInt(1, sessionId); // session_id
                } else {
                    preparedStatement.setNull(1, java.sql.Types.INTEGER); // NULL gönder
                }

                // seat_number kontrol et
                if (seatNumber != null && !seatNumber.isEmpty()) {
                    preparedStatement.setString(2, seatNumber); // seat_number
                } else {
                    preparedStatement.setNull(2, java.sql.Types.VARCHAR); // NULL gönder
                }

                // Ürün bilgilerini ekle
                preparedStatement.setString(3, productName); // product_name
                preparedStatement.setDouble(4, productPrice); // product_price

                // Her ürün için sorguyu ekle
                preparedStatement.addBatch();
            }

            // Toplu sorguyu çalıştır
            int[] rowsInserted = preparedStatement.executeBatch();
            return rowsInserted.length == selectedProducts.size(); // Eklenen satır sayısını kontrol et
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * Uyarı mesajı gösterir.
     */
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleClearSelection() {
        // Seçimleri temizle
        productsListView.getSelectionModel().clearSelection();
    }

    @FXML
    private void handleClose() {
        // Pencereyi kapat
        Stage stage = (Stage) productsListView.getScene().getWindow();
        stage.close();
    }

}
