package com.group04.cinemaapp.controllers;

import com.group04.cinemaapp.Database;
import com.group04.cinemaapp.models.Session;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SessionManagementController {

    @FXML
    private TableView<Session> sessionTable;
    @FXML
    private TableColumn<Session, Integer> idColumn;
    @FXML
    private TableColumn<Session, String> movieNameColumn, dateColumn, timeColumn, hallColumn;
    @FXML
    private TextField movieNameField, timeField, hallField;
    @FXML
    private DatePicker datePicker;

    private ObservableList<Session> sessionList = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        // Tablodaki sütunları bağlama
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        movieNameColumn.setCellValueFactory(new PropertyValueFactory<>("movieName"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        hallColumn.setCellValueFactory(new PropertyValueFactory<>("hall"));

        loadSessions(); // Tablodaki oturumları yükle
    }

    private void loadSessions() {
        sessionList.clear();
        String sql = "SELECT s.id, m.title AS movieName, s.date, s.time, h.name AS hall " +
                "FROM Sessions s " +
                "JOIN Movies m ON s.movie_id = m.id " +
                "JOIN Halls h ON s.hall_id = h.id";

        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                sessionList.add(new Session(
                        rs.getInt("id"),
                        rs.getString("movieName"),
                        rs.getString("date"),
                        rs.getString("time"),
                        rs.getString("hall")
                ));
            }
            sessionTable.setItems(sessionList);  // Tabloyu yenile
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load sessions from the database.");
        }
    }


    @FXML
    private void handleAddSession(ActionEvent event) {
        String movieName = movieNameField.getText();
        String date = (datePicker.getValue() != null) ? datePicker.getValue().toString() : "";
        String time = timeField.getText();
        String hall = hallField.getText();

        if (movieName.isEmpty() || date.isEmpty() || time.isEmpty() || hall.isEmpty()) {
            showAlert("Error", "All fields must be filled.");
            return;
        }

        // Film ve salon geçerliliğini kontrol et
        if (!isMovieAndHallValid(movieName, hall)) {
            return;
        }

        // Salon kapasitesini al
        String hallCapacitySql = "SELECT capacity FROM Halls WHERE name = ?";
        int hallCapacity = 0;
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(hallCapacitySql)) {
            stmt.setString(1, hall);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                hallCapacity = rs.getInt("capacity");
            } else {
                showAlert("Error", "Hall not found.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to retrieve hall capacity.");
            return;
        }

        // Oturum ekleme SQL sorgusu
        String sql = "INSERT INTO Sessions (movie_id, hall_id, date, time, available_seats) " +
                "VALUES ((SELECT id FROM Movies WHERE title = ?), " +
                "(SELECT id FROM Halls WHERE name = ?), ?, ?, ?)";

        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, movieName);
            stmt.setString(2, hall);
            stmt.setString(3, date);
            stmt.setString(4, time);
            stmt.setInt(5, hallCapacity); // Salon kapasitesini available_seats olarak ayarlıyoruz

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                showAlert("Success", "Session added successfully.");
                loadSessions(); // Tabloyu yenile
                clearFields();
            } else {
                showAlert("Error", "Failed to add session. Ensure movie and hall exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to add session.");
        }
    }


    @FXML
    private void handleUpdateSession(ActionEvent event) {
        Session selectedSession = sessionTable.getSelectionModel().getSelectedItem();
        if (selectedSession == null) {
            showAlert("Error", "Please select a session to update.");
            return;
        }

        String date = (datePicker.getValue() != null) ? datePicker.getValue().toString() : "";
        String time = timeField.getText();
        String hall = hallField.getText();

        if (date.isEmpty() || time.isEmpty() || hall.isEmpty()) {
            showAlert("Error", "All fields must be filled.");
            return;
        }

        // Film ve salon geçerliliğini kontrol et
        if (!isMovieAndHallValid(selectedSession.getMovieName(), hall)) {
            return;
        }

        String sql = "UPDATE Sessions SET date = ?, time = ?, hall_id = (SELECT id FROM Halls WHERE name = ?) WHERE id = ?";

        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, date);
            stmt.setString(2, time);
            stmt.setString(3, hall);
            stmt.setInt(4, selectedSession.getId());

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                showAlert("Success", "Session updated successfully.");
                loadSessions(); // Tabloyu yenile
                clearFields();
            } else {
                showAlert("Error", "Failed to update session.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to update session.");
        }
    }

    @FXML
    private void handleDeleteSession(ActionEvent event) {
        Session selectedSession = sessionTable.getSelectionModel().getSelectedItem();
        if (selectedSession == null) {
            showAlert("Error", "Please select a session to delete.");
            return;
        }

        String sql = "DELETE FROM Sessions WHERE id = ?";

        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, selectedSession.getId());

            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                showAlert("Success", "Session deleted successfully.");
                loadSessions(); // Tabloyu yenile
            } else {
                showAlert("Error", "Failed to delete session.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to delete session.");
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            // AdminMainMenu.fxml dosyasını yükle
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AdminMainMenu.fxml"));
            Parent root = loader.load();

            // Mevcut sahneyi al ve yeni sahneyle değiştir
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Admin Main Menu");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to navigate back to the Admin Main Menu.");
        }
    }

    private boolean isMovieAndHallValid(String movieName, String hallName) {
        String movieSql = "SELECT id FROM Movies WHERE title = ?";
        String hallSql = "SELECT id FROM Halls WHERE name = ?";

        try (Connection conn = Database.getConnection()) {
            // Film kontrolü
            PreparedStatement movieStmt = conn.prepareStatement(movieSql);
            movieStmt.setString(1, movieName);
            ResultSet movieRs = movieStmt.executeQuery();
            if (!movieRs.next()) {
                showAlert("Error", "Movie not found.");
                return false;
            }

            // Salon kontrolü
            PreparedStatement hallStmt = conn.prepareStatement(hallSql);
            hallStmt.setString(1, hallName);
            ResultSet hallRs = hallStmt.executeQuery();
            if (!hallRs.next()) {
                showAlert("Error", "Hall not found.");
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to validate movie and hall.");
            return false;
        }
        return true;
    }

    private void clearFields() {
        movieNameField.clear();
        datePicker.setValue(null);
        timeField.clear();
        hallField.clear();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
