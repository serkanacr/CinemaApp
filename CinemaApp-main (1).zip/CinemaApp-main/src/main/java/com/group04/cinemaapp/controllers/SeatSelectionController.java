package com.group04.cinemaapp.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashSet;
import java.util.Set;

public class SeatSelectionController {

    @FXML
    private Label movieNameLabel;

    @FXML
    private Label sessionTimeLabel;

    @FXML
    private GridPane seatGrid;

    @FXML
    private Label selectedSeatsLabel;

    @FXML
    private ImageView posterImageView;

    private Set<String> selectedSeats = new HashSet<>();
    private int sessionId;
    private String movieTitle;
    private String sessionTime;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/group04";
    private static final String DB_USER = "myuser";
    private static final String DB_PASSWORD = "1234";

    /**
     * Sets movie details and initializes seat selection.
     */
    public void setMovieDetails(int sessionId, String movieTitle, String movieGenre) {
        this.sessionId = sessionId;
        this.movieTitle = movieTitle;

        movieNameLabel.setText(movieTitle);
        sessionTimeLabel.setText(movieGenre); // Film türünü göster

        // Poster resmi yükleme ile ilgili satırları kaldırın
        // Seans bilgilerini yükleme
        loadSessionDetails();
    }





    /**
     * Loads session details and initializes seat grid.
     */
    private void loadSessionDetails() {
        String query = "SELECT time FROM sessions WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, sessionId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                sessionTime = resultSet.getString("time");
                sessionTimeLabel.setText(sessionTime);
                setupSeatGrid();
            } else {
                showAlert("Error", "Session details not found!", Alert.AlertType.ERROR);
            }
        } catch (Exception e) {
            showAlert("Database Error", "Unable to load session details: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Sets up the seat grid dynamically.
     */
    private void setupSeatGrid() {
        seatGrid.getChildren().clear();

        String query = "SELECT seat_number, is_reserved FROM seats WHERE session_id = ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, sessionId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String seatNumber = resultSet.getString("seat_number");
                boolean isReserved = resultSet.getBoolean("is_reserved");

                Button seatButton = new Button(seatNumber);
                seatButton.setDisable(isReserved);
                seatButton.setStyle(isReserved ? "-fx-background-color: #f44336;" : "-fx-background-color: #4caf50;");
                seatButton.setOnAction(event -> handleSeatSelection(seatButton));

                int row = (seatNumber.charAt(0) - 'A');
                int col = Integer.parseInt(seatNumber.substring(1)) - 1;
                seatGrid.add(seatButton, col, row);
            }
        } catch (Exception e) {
            showAlert("Database Error", "Unable to load seats: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Handles seat selection logic.
     */
    private void handleSeatSelection(Button seatButton) {
        String seat = seatButton.getText();
        if (selectedSeats.contains(seat)) {
            selectedSeats.remove(seat);
            seatButton.setStyle("-fx-background-color: #4caf50; -fx-text-fill: white;");
        } else {
            selectedSeats.add(seat);
            seatButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");
        }
        updateSelectedSeatsLabel();
    }

    /**
     * Updates the label displaying selected seats.
     */
    private void updateSelectedSeatsLabel() {
        selectedSeatsLabel.setText(selectedSeats.isEmpty() ? "None" : String.join(", ", selectedSeats));
    }

    /**
     * Confirms the seat selection and navigates to payment.
     */
    @FXML
    private void handleConfirm(ActionEvent event) {
        if (selectedSeats.isEmpty()) {
            showAlert("No Seats Selected", "Please select at least one seat to confirm.", Alert.AlertType.WARNING);
        } else {
            lockSelectedSeats();
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();
            navigateToProcessPayment();
        }
    }

    /**
     * Navigates to the payment screen.
     */
    private void navigateToProcessPayment() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ShoppingCart.fxml"));
            Parent root = loader.load();

            ShoppingCartController controller = loader.getController();
            ObservableList<String> seatsObservableList = FXCollections.observableArrayList(selectedSeats);
            controller.setPaymentDetails(movieTitle, sessionTime, seatsObservableList, sessionId);

            Stage stage = new Stage();
            stage.setTitle("Process Payment");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            showAlert("Navigation Error", "Unable to navigate to ShoppingCart: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Clears the seat selection.
     */
    @FXML
    private void handleClear(ActionEvent event) {
        // Seçilen koltukları temizle
        selectedSeats.clear();

        // Grid'deki tüm koltukları tekrar kontrol et ve durumlarına göre güncelle
        seatGrid.getChildren().forEach(node -> {
            if (node instanceof Button) {
                Button seatButton = (Button) node;
                // Eğer koltuk rezerve edilmişse kırmızı bırak ve tıklanamaz yap
                if (seatButton.isDisable()) {
                    seatButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;"); // Kırmızı
                } else {
                    // Rezerve edilmemiş koltukları yeşil yap
                    seatButton.setStyle("-fx-background-color: #4caf50; -fx-text-fill: white;"); // Yeşil
                }
            }
        });

        // Etiketi güncelle
        updateSelectedSeatsLabel();
    }


    /**
     * Shows an alert dialog.
     */
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Locks selected seats and updates the database.
     */
    private void lockSelectedSeats() {
        seatGrid.getChildren().forEach(node -> {
            if (node instanceof Button) {
                Button seatButton = (Button) node;
                if (selectedSeats.contains(seatButton.getText())) {
                    seatButton.setDisable(true);
                    seatButton.setStyle("-fx-background-color: #d32f2f; -fx-text-fill: white;");
                }
            }
        });

        updateAvailableSeatsInDatabase();
    }

    /**
     * Updates available seats in the database.
     */
    private void updateAvailableSeatsInDatabase() {
        String query = "UPDATE sessions SET available_seats = available_seats - ? WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, selectedSeats.size());
            preparedStatement.setInt(2, sessionId);
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            showAlert("Database Error", "Unable to update available seats: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            // Önce MovieSearch.fxml dosyasını yükleyin
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/MovieSearch.fxml"));
            Parent root = loader.load();

            // Yeni bir sahne (Stage) oluşturun ve gösterin
            Stage stage = new Stage();
            stage.setTitle("Movie Search");
            stage.setScene(new Scene(root));
            stage.show();

            // Mevcut sahneyi (Stage) kapatın
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            // Hata durumunda bir uyarı gösterin
            showAlert("Navigation Error", "Unable to navigate back to Movie Search: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }
    @FXML
    private void handleProductSelection() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ProductSelection.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Product Selection");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            showAlert("Navigation Error", "Unable to load Product Selection screen: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }


    /**
     * Returns a database connection.
     */
    private Connection getConnection() throws Exception {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
}
