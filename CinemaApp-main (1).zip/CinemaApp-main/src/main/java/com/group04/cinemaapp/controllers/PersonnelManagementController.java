package com.group04.cinemaapp.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import com.group04.cinemaapp.models.User;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class PersonnelManagementController {

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/group04";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    @FXML private TableView<User> personnelTable;
    @FXML private TableColumn<User, String> idColumn;
    @FXML private TableColumn<User, String> usernameColumn;
    @FXML private TableColumn<User, String> firstNameColumn;
    @FXML private TableColumn<User, String> lastNameColumn;
    @FXML private TableColumn<User, String> passwordColumn;
    @FXML private TableColumn<User, String> roleColumn;

    @FXML private TextField idField;
    @FXML private TextField usernameField;
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField passwordField;
    @FXML private TextField roleField;

    private ObservableList<User> personnelList = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        // Connect TableView colujmns to model
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        passwordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));
        roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));

        loadPersonnelData();
    }

    private void loadPersonnelData() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT * FROM users";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String role = rs.getString("role");
                String firstName = rs.getString("firstname");
                String lastName = rs.getString("lastname");


                personnelList.add(new User(id, username, password, role, firstName, lastName));
            }

            personnelTable.setItems(personnelList);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private boolean isUsernameTaken(String username) {
        String query = "SELECT COUNT(*) FROM users WHERE username = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private static final String[] validRoles = {"cashier", "admin", "manager"};

    private boolean isValidRole(String role) {
        for (String validRole : validRoles) {
            if (validRole.equalsIgnoreCase(role)) {
                return true;
            }
        }
        return false;
    }


    @FXML
    private void handleHirePersonnel() {
        try {
            String username = usernameField.getText().trim();
            String firstName = firstNameField.getText().trim();
            String lastName = lastNameField.getText().trim();
            String password = passwordField.getText().trim();
            String role = roleField.getText().trim();

            if (username.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || password.isEmpty() || role.isEmpty()) {
                showAlert("Missing Information", "All fields must be filled.", Alert.AlertType.WARNING);
                return;
            }

            if (isUsernameTaken(username)) {
                showAlert("Username Taken", "This username is already taken. Please choose a different one.", Alert.AlertType.WARNING);
                return;
            }

            if (!isValidRole(role)) {
                showAlert("Error", "Invalid role! Valid roles are: cashier, admin, manager.", Alert.AlertType.ERROR);
                return;
            }


            User newPersonnel = new User(0, username, password, role, firstName, lastName );


            savePersonnelToDatabase(newPersonnel);


            usernameField.clear();
            firstNameField.clear();
            lastNameField.clear();
            passwordField.clear();
            roleField.clear();


            showAlert("Personnel Added", "The personnel has been added successfully.", Alert.AlertType.INFORMATION);

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while adding the personnel. Please try again.", Alert.AlertType.ERROR);
        }
    }

    private void savePersonnelToDatabase(User personnel) {

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {

            String sql = "INSERT INTO users (username, firstname, lastname, password, role) VALUES (?, ?, ?, ?, ?)";


            PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);


            pst.setString(1, personnel.getUsername());
            pst.setString(2, personnel.getFirstName());
            pst.setString(3, personnel.getLastName());
            pst.setString(4, personnel.getPassword());
            pst.setString(5, personnel.getRole());


            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet generatedKeys = pst.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int generatedId = generatedKeys.getInt(1);
                    personnel.setId(generatedId);
                    System.out.println("Personnel added successfully with ID: " + generatedId);
                    personnelList.add(personnel);
                }
            } else {
                System.out.println("No rows affected. Personnel was not added.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "An error occurred while saving the personnel to the database.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleFirePersonnel() {
        String username = usernameField.getText();

        if (username.isEmpty()) {
            showAlert("Error", "Username must be provided to fire personnel!", Alert.AlertType.ERROR);
            return;
        }

        if (username.equals(LoginController.loggedInUsername)) {
            showAlert("Error", "You cannot fire yourself!", Alert.AlertType.ERROR);
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "DELETE FROM users WHERE username = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, username);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                personnelList.clear();
                loadPersonnelData();
                showAlert("Success", "Personnel fired successfully!", Alert.AlertType.INFORMATION);
                clearFields();
            } else {
                showAlert("Error", "Personnel not found!", Alert.AlertType.ERROR);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleEdit() {
        User selectedUser = personnelTable.getSelectionModel().getSelectedItem();

        if (selectedUser == null) {
            showAlert("Error", "No personnel selected! Please select a personnel to edit.", Alert.AlertType.WARNING);
            return;
        }

        String newUsername = usernameField.getText().trim();
        String newFirstName = firstNameField.getText().trim();
        String newLastName = lastNameField.getText().trim();
        String newPassword = passwordField.getText().trim();
        String newRole = roleField.getText().trim();

        if (newUsername.isEmpty() || newFirstName.isEmpty() || newLastName.isEmpty() || newPassword.isEmpty() || newRole.isEmpty()) {
            showAlert("Error", "All fields must be filled to update personnel.", Alert.AlertType.WARNING);
            return;
        }

        if (!isValidRole(newRole)) {
            showAlert("Error", "Invalid role! Valid roles are: cashier, admin, manager.", Alert.AlertType.ERROR);
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "UPDATE users SET username = ?, firstname = ?, lastname = ?, password = ?, role = ? WHERE id = ?";
            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, newUsername);
            pst.setString(2, newFirstName);
            pst.setString(3, newLastName);
            pst.setString(4, newPassword);
            pst.setString(5, newRole);
            pst.setInt(6, selectedUser.getId());

            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                selectedUser.setUsername(newUsername);
                selectedUser.setFirstName(newFirstName);
                selectedUser.setLastName(newLastName);
                selectedUser.setPassword(newPassword);
                selectedUser.setRole(newRole);

                personnelTable.refresh();
                showAlert("Success", "Personnel updated successfully!", Alert.AlertType.INFORMATION);
                clearFields();
            } else {
                showAlert("Error", "Personnel update failed. Please try again.", Alert.AlertType.ERROR);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleBack() {
        Stage stage = (Stage) usernameField.getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void clearFields() {
        usernameField.clear();
        firstNameField.clear();
        lastNameField.clear();
        passwordField.clear();
        roleField.clear();
    }
}
