package com.group04.cinemaapp.controllers;

import com.group04.cinemaapp.Database;
import com.group04.cinemaapp.models.Movie;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.net.URL;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MovieManagementController {

    @FXML
    private TextField titleField, genreField, posterPathField;
    @FXML
    private TextArea summaryField;
    @FXML
    private TableView<Movie> movieTable;
    @FXML
    private TableColumn<Movie, Integer> idColumn;
    @FXML
    private TableColumn<Movie, String> titleColumn, genreColumn, summaryColumn, posterPathColumn;

    private String selectedPosterPath;

    @FXML
    public void initialize() {
        
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        genreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
        summaryColumn.setCellValueFactory(new PropertyValueFactory<>("summary"));
        posterPathColumn.setCellValueFactory(new PropertyValueFactory<>("posterPath"));

        
        handleRefreshTable();
    }

    @FXML
    private void handleAddMovie(ActionEvent event) {
        String title = titleField.getText();
        String genre = genreField.getText();
        String summary = summaryField.getText();
        String posterPath = posterPathField.getText();  // Tam yol al

        
        if (title.isEmpty() || genre.isEmpty() || summary.isEmpty() || posterPath.isEmpty()) {
            showAlert("Error", "All fields must be filled, including poster path.");
            return;
        }

        
        File file = new File(posterPath);
        if (!file.exists()) {
            showAlert("Error", "Poster file not found at the given path: " + posterPath);
            return;
        }

       
        String sql = "INSERT INTO Movies (title, genre, summary, poster_path) VALUES (?, ?, ?, ?)";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, title);
            stmt.setString(2, genre);
            stmt.setString(3, summary);
            stmt.setString(4, posterPath);  // Poster yolunu kaydet
            stmt.executeUpdate();
            showAlert("Success", "Movie added successfully.");
            handleRefreshTable();  // Tabloyu güncelle
            clearForm();  // Formu temizle
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to add movie.");
        }
    }



    @FXML
    private void handleUpdateMovie(ActionEvent event) {
        Movie selectedMovie = movieTable.getSelectionModel().getSelectedItem();

        if (selectedMovie == null) {
            showAlert("Error", "Please select a movie to update.");
            return;
        }

        String updatedTitle = titleField.getText();
        String updatedGenre = genreField.getText();
        String updatedSummary = summaryField.getText();
        String updatedPosterPath = posterPathField.getText();  // Poster yolunu al

        // Form alanlarının boş olup olmadığını kontrol et
        if (updatedTitle.isEmpty() || updatedGenre.isEmpty() || updatedSummary.isEmpty() || updatedPosterPath.isEmpty()) {
            showAlert("Error", "All fields must be filled, including poster path.");
            return;
        }

        
        File file = new File(updatedPosterPath);
        if (!file.exists()) {
            showAlert("Error", "Poster file not found at the given path: " + updatedPosterPath);
            return;
        }

        
        String sql = "UPDATE Movies SET title = ?, genre = ?, summary = ?, poster_path = ? WHERE id = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, updatedTitle);
            stmt.setString(2, updatedGenre);
            stmt.setString(3, updatedSummary);
            stmt.setString(4, updatedPosterPath); 
            stmt.setInt(5, selectedMovie.getId());
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                showAlert("Success", "Movie updated successfully.");
                handleRefreshTable();  
                clearForm();  
            } else {
                showAlert("Error", "Failed to update the movie.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while updating the movie.");
        }
    }

    @FXML
    private void handleDeleteMovie(ActionEvent event) {
        Movie selectedMovie = movieTable.getSelectionModel().getSelectedItem();

        if (selectedMovie == null) {
            showAlert("Error", "Please select a movie to delete.");
            return;
        }

        
        String sql = "DELETE FROM Movies WHERE id = ?";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, selectedMovie.getId());
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                showAlert("Success", "Movie deleted successfully.");
                handleRefreshTable(); 
                clearForm(); 
            } else {
                showAlert("Error", "Failed to delete the movie.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to delete movie.");
        }
    }

    @FXML
    private void handleClearForm(ActionEvent event) {
        clearForm(); 
    }

    @FXML
    private void handleRefreshTable() {
        String sql = "SELECT * FROM Movies";
        try (Connection conn = Database.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            ObservableList<Movie> movies = FXCollections.observableArrayList();
            while (rs.next()) {
                String posterPath = rs.getString("poster_path");
                String posterFileName = new File(posterPath).getName(); 

                movies.add(new Movie(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getString("summary"),
                        posterFileName  
                ));
            }
            movieTable.setItems(movies);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load movies.");
        }
    }




    @FXML
    private void handleBack(ActionEvent event) {
        try {
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AdminMainMenu.fxml"));
            Parent root = loader.load();

            
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Admin Main Menu");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to navigate back to the Admin Main Menu.");
        }
    }


    private void clearForm() {
        titleField.clear();
        genreField.clear();
        summaryField.clear();
        posterPathField.clear();
        movieTable.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleBrowsePoster(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));

        
        URL resourceURL = getClass().getClassLoader().getResource("images");  

        
        if (resourceURL != null) {
            File folder = new File(resourceURL.getPath());
            if (folder.exists()) {
                fileChooser.setInitialDirectory(folder);  
            }
        }

        
        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            
            posterPathField.setText(selectedFile.getAbsolutePath()); 
            selectedPosterPath = selectedFile.getAbsolutePath();  
        }
    }


}

