package com.group04.cinemaapp.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

public class ShoppingCartController {

    @FXML
    private ListView<String> seatListView;

    @FXML
    private ListView<String> additionalItemsListView;

    @FXML
    private Label totalAmountLabel;

    @FXML
    private Label discountLabel;

    @FXML
    private Button checkoutButton;

    private ObservableList<String> selectedSeats = FXCollections.observableArrayList();
    private ObservableList<String> additionalItems = FXCollections.observableArrayList();

    private double totalAmount = 0.0;
    private double totalDiscount = 0.0;
    private double ticketPrice = 10.0;
    private double discountRate = 0.1;
    private double taxRate = 0.2;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/group04";
    private static final String DB_USER = "myuser";
    private static final String DB_PASSWORD = "1234";

    private int sessionId;
    private boolean isDiscountApplied = false;

    /**
     * JavaFX'in initialize metodu.
     */
    @FXML
    public void initialize() {
        loadTicketSettings(); // Veritabanından bilet fiyatı, indirim oranı ve vergi oranını yükler
        additionalItemsListView.setItems(additionalItems); // Ek ürünleri listeye bağlar
        seatListView.setItems(selectedSeats); // Seçilen koltukları listeye bağlar
        calculateTotal(selectedSeats.size(), false); // Başlangıç toplamını hesaplar
    }

    /**
     * Veritabanından bilet fiyatı, indirim oranı ve vergi oranını yükler.
     */
    private void loadTicketSettings() {
        String query = "SELECT ticket_price, discount_rate, tax_rate FROM settings LIMIT 1";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            if (resultSet.next()) {
                ticketPrice = resultSet.getDouble("ticket_price");
                discountRate = resultSet.getDouble("discount_rate");
                taxRate = resultSet.getDouble("tax_rate");
            }
        } catch (Exception e) {
            showAlert("Database Error", "Unable to load ticket settings: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Seçilen koltuklar ve ek ürünlere göre toplam tutarı hesaplar.
     */
    private void calculateTotal(int numberOfSeats, boolean applyDiscount) {
        // Toplam bilet fiyatını hesapla
        totalAmount = ticketPrice * numberOfSeats;

        // Ek ürünlerin toplam fiyatını hesapla
        for (String item : additionalItems) {
            String[] parts = item.split(" - "); // Format: "Ürün Adı - $10.00"
            double productPrice = Double.parseDouble(parts[1].replace("$", ""));
            totalAmount += productPrice; // Ürün fiyatını ekle
        }

        // İndirim hesaplama
        if (applyDiscount) {
            totalDiscount = totalAmount * discountRate;
        } else {
            totalDiscount = 0.0;
        }

        // Vergi hesaplama
        double taxAmount = (totalAmount - totalDiscount) * taxRate;

        // İndirim ve vergi dahil toplam tutar
        totalAmount = totalAmount - totalDiscount + taxAmount;

        // UI'yi güncelle
        totalAmountLabel.setText(String.format("%.2f USD", totalAmount));
        discountLabel.setText(String.format("%.2f USD", totalDiscount));
    }

    /**
     * İndirim butonuna basıldığında çalışır.
     */
    @FXML
    private void applyDiscount(ActionEvent event) {
        if (isDiscountApplied) {
            isDiscountApplied = false;
            showAlert("Discount Removed", "Discount has been removed successfully!", Alert.AlertType.INFORMATION);
        } else {
            isDiscountApplied = true;
            showAlert("Discount Applied", "Discount has been successfully applied!", Alert.AlertType.INFORMATION);
        }
        calculateTotal(selectedSeats.size(), isDiscountApplied);
    }

    /**
     * Ödeme butonuna basıldığında çalışır.
     */
    @FXML
    private void handleCheckout(ActionEvent event) {
        if (selectedSeats.isEmpty()) {
            showAlert("Checkout Error", "No seats selected for payment!", Alert.AlertType.WARNING);
            return;
        }

        double finalAmount = totalAmount;

        boolean paymentSuccessful = processPayment(finalAmount);
        if (paymentSuccessful) {
            updateSeatReservations();
            showAlert("Success", "Your payment of " + String.format("%.2f USD", finalAmount) + " has been processed successfully.", Alert.AlertType.INFORMATION);
            checkoutButton.getScene().getWindow().hide(); // Pencereyi kapat
        } else {
            showAlert("Payment Error", "Payment failed. Please try again.", Alert.AlertType.ERROR);
        }
    }

    /**
     * Ödeme bilgilerini veritabanına kaydeder.
     */
    private boolean processPayment(double finalAmount) {
        String query = "INSERT INTO payments (amount, discount, seats, additional_items) VALUES (?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setDouble(1, finalAmount);
            preparedStatement.setDouble(2, totalDiscount);
            preparedStatement.setString(3, String.join(", ", selectedSeats));
            preparedStatement.setString(4, String.join(", ", additionalItems));

            int rowsInserted = preparedStatement.executeUpdate();
            return rowsInserted > 0;

        } catch (Exception e) {
            showAlert("Database Error", "Unable to save payment details: " + e.getMessage(), Alert.AlertType.ERROR);
            return false;
        }
    }

    /**
     * Seçilen koltukların rezervasyon durumunu günceller.
     */
    private void updateSeatReservations() {
        String query = "UPDATE seats SET is_reserved = TRUE WHERE session_id = ? AND seat_number = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            for (String seat : selectedSeats) {
                try (PreparedStatement seatStatement = connection.prepareStatement(query)) {
                    seatStatement.setInt(1, sessionId);
                    seatStatement.setString(2, seat);
                    seatStatement.executeUpdate();
                }
            }
        } catch (Exception e) {
            showAlert("Database Error", "Unable to update seat reservations: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Veritabanından ek ürünleri yükler.
     */
    private void loadProductsFromDatabase() {
        additionalItems.clear();

        String query = "SELECT product_name, product_price FROM orderdetails WHERE session_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, sessionId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String productName = resultSet.getString("product_name");
                double productPrice = resultSet.getDouble("product_price");
                double taxAmount = productPrice * taxRate;
                double finalPrice = productPrice + taxAmount;

                additionalItems.add(productName + " - " + String.format("%.2f USD (Tax: %.2f USD)", finalPrice, taxAmount));
            }
            additionalItemsListView.setItems(additionalItems);

        } catch (Exception e) {
            showAlert("Database Error", "Unable to load products from database: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Kullanıcıya bilgi gösterir.
     */
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Seçilen koltukları ekler ve günceller.
     */
    public void updateShoppingCartView( ObservableList<String> products) {
// Ürünleri güncelle
        additionalItems.clear();
        additionalItems.addAll(products);
        additionalItemsListView.setItems(additionalItems);

        // Toplam fiyatı hesapla
        calculateProductTotal();
    }



    /**
     * Alınan film başlığı, seans zamanı, seçili koltuklar ve seans kimliğine göre
     * kullanıcı alışveriş sepetini doldurur ve ilgili UI öğelerini günceller.
     *
     * @param movieTitle       Film başlığı
     * @param sessionTime      Seans zamanı
     * @param seatsObservableList Seçilen koltukların listesi
     * @param sessionId        Seans kimliği
     */
    public void setPaymentDetails(String movieTitle, String sessionTime, ObservableList<String> seatsObservableList, int sessionId) {
        // Seans kimliğini sakla
        this.sessionId = sessionId;

        // Seçilen koltukları listeye ekle ve UI öğesini güncelle
        selectedSeats.clear();
        selectedSeats.addAll(seatsObservableList);
        seatListView.setItems(selectedSeats);

        // Ek ürünleri yükle (varsa)
        loadProductsFromDatabase();

        // Toplam tutarı güncelle
        calculateTotal(selectedSeats.size(), isDiscountApplied);

        // Debug veya loglama için kullanıcıya detayları yazdır
        System.out.println("Payment Details Set:");
        System.out.println("Movie Title: " + movieTitle);
        System.out.println("Session Time: " + sessionTime);
        System.out.println("Seats Selected: " + seatsObservableList);
        System.out.println("Session ID: " + sessionId);
    }
    private double calculateProductTotal() {
        double productTotal = 0.0;

        for (String item : additionalItems) {
            String[] parts = item.split(" - "); // Örnek: "Beverage - $10.00"
            double productPrice = Double.parseDouble(parts[1].replace("$", "").replace(",", "."));
            productTotal += productPrice; // Her ürün fiyatını topla
        }

        System.out.println("Product total calculated: " + productTotal);
        return productTotal;
    }


}
