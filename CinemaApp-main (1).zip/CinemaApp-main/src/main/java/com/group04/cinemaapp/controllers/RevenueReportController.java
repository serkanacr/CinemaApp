package com.group04.cinemaapp.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.sql.*;

public class RevenueReportController {

    @FXML private TextField RevenueField;
    @FXML private TextField TaxField;
    @FXML private TableView<?> productTable; // Eğer tabloyu kullanmıyorsanız, bu satırı kaldırabilirsiniz

    // Veritabanı bağlantısı için gerekli bilgiler (değiştirmeniz gerekebilir)
    private static final String DB_URL = "jdbc:mysql://localhost:3306/group04";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    @FXML
    public void initialize() {
        // Başlangıçta verileri hesapla
        calculateRevenueAndTax();
    }

    public void calculateRevenueAndTax() {
        double totalRevenue = 0.0;

        // Veritabanı bağlantısı oluşturma ve veri çekme
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT amount FROM payments";
            try (Statement stmt = connection.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {

                // Amount değerlerini topla
                while (rs.next()) {
                    totalRevenue += rs.getDouble("amount");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Hata durumunda konsola yazdır
        }

        // Hesaplanan toplam geliri RevenueField'a yaz
        RevenueField.setText(String.format("%.2f", totalRevenue));

        // Vergiyi hesapla (%20)
        double tax = totalRevenue * 0.20;

        // Hesaplanan vergiyi TaxField'a yaz
        TaxField.setText(String.format("%.2f", tax));
    }

    // Back butonuna tıklanması durumu
    @FXML
    private void handleBack() {
        Stage stage = (Stage) TaxField.getScene().getWindow();
        stage.close();
    }
}


