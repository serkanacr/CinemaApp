package com.group04.cinemaapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {

    // Veritabanı bağlantı bilgileri
    private static final String URL = "jdbc:mysql://localhost:3306/group04"; // Veritabanı adı: cinemacenter
    private static final String USER = "root"; // Kullanıcı adı
    private static final String PASSWORD = "1234"; // Şifre

    // Veritabanı bağlantısını döndüren bir metod
    public static Connection getConnection() throws SQLException {
        // Bağlantıyı oluştur ve döndür
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
