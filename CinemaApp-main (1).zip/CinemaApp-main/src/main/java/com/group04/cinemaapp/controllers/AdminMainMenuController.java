package com.group04.cinemaapp.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class AdminMainMenuController {

    @FXML
    private void handleLogout(ActionEvent event) {
        showAlert("Logout", "Logging out...");
        Stage currentStage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        currentStage.close();
        navigateTo("/Login.fxml", "Movie Management");

    }

    @FXML
    private void handleManageMovies(ActionEvent event) {
        navigateTo("/MovieManagement.fxml", "Movie Management");
    }

    @FXML
    private void handlePlanSessions(ActionEvent event) {
        navigateTo("/SessionManagement.fxml", "Plan Sessions");
    }

    @FXML
    private void handleProcessCancellations(ActionEvent event) {
        navigateTo("/Cancellations.fxml", "Process Cancellations");
    }



    private void navigateTo(String fxmlPath, String title) {
        try {
            URL location = getClass().getResource(fxmlPath);
            if (location == null) {
                System.out.println("FXML file not found: " + fxmlPath);
                return;
            }
            FXMLLoader loader = new FXMLLoader(location);
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to navigate to " + title);
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
